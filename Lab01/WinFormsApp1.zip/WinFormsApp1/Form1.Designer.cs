﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblName = new Label();
            txtName = new TextBox();
            txtOutput = new TextBox();
            btnGreet = new Button();
            SuspendLayout();
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new Point(27, 23);
            lblName.Name = "lblName";
            lblName.Size = new Size(102, 15);
            lblName.TabIndex = 0;
            lblName.Text = "Enter Your Name: ";
            lblName.Click += label1_Click;
            // 
            // txtName
            // 
            txtName.Location = new Point(149, 20);
            txtName.Name = "txtName";
            txtName.Size = new Size(166, 23);
            txtName.TabIndex = 1;
            txtName.TextChanged += txtName_TextChanged;
            // 
            // txtOutput
            // 
            txtOutput.Location = new Point(29, 108);
            txtOutput.Name = "txtOutput";
            txtOutput.ReadOnly = true;
            txtOutput.Size = new Size(286, 23);
            txtOutput.TabIndex = 2;
            // 
            // btnGreet
            // 
            btnGreet.Location = new Point(29, 58);
            btnGreet.Name = "btnGreet";
            btnGreet.Size = new Size(286, 32);
            btnGreet.TabIndex = 3;
            btnGreet.Text = "Say Hi";
            btnGreet.UseVisualStyleBackColor = true;
            btnGreet.Click += btnGreet_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(344, 164);
            Controls.Add(btnGreet);
            Controls.Add(txtOutput);
            Controls.Add(txtName);
            Controls.Add(lblName);
            Name = "Form1";
            Text = "Greeting App";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblName;
        private TextBox txtName;
        private TextBox txtOutput;
        private Button btnGreet;
    }
}

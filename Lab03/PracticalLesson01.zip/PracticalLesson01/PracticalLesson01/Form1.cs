namespace PracticalLesson01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnClick_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = "Welcome to Visual Programming C#";
        }
    }
}
